from os import path
import operator
import csv

from PIL import Image
import numpy as np
from wordcloud import WordCloud
import matplotlib.pyplot as plt

from filtering import Filtering

d = path.dirname(__file__)

class GetDocuments():
	"""docstring for GetDocuments"""
	def __init__(self):
		pass


class ReadFromFile():
	"""docstring for ReadFromFile"""
	def __init__(self):
		pass

	def get_text_from_txt(self, filename):
		return open(filename).read()

	def get_text_from_doc(self, filename):
		""" 
			use doc module
		"""
		pass
	def get_text_from_pdf(self, filename):
		""" 
			use pdf module
		"""
		pass


class WriteToFile():
	def write_to_csv(self, filenane):
		pass


class WordFreq():
	"""docstring for WordFreq"""
	def __init__(self):
		self.frequent = {}

	def _convert_into_word_cloud(self, freq, filename):
		key_array = [key for (key, value) in freq]
		wordcloud = WordCloud().generate(" ".join(key_array))
		wordcloud.to_file(path.join(filename))

	def most_frequents(self, text):
		"""
			tf_list.csv
			Most frequent 50 words in the input set of documents, sorted descending
		by their term frequency (tf) coupled with their tf values (comma seperated file,
		example: document;7)
		"""
		for word in text:
			self.frequent[word] = self.frequent.get(word, 0) + 1
		return self.frequent

	def word_cloud(self, freq):
		"""
			tf_wordCloud.pdf
			Word cloud of the these words
		"""
		self._convert_into_word_cloud(freq, "tf_wordCloud.pdf")


	def tfidf_list(self):
		""" 
			tfidf_list.csv
			Most frequent 50 words in the input set of documents, sorted
		descending by their term frequency*inverse document frequency (tf-idf) coupled
		with their tf-idf values (comma seperated file, example: document;2.8) 
		"""
		pass

	def tfidf_word_cloud(self):
		"""
			Word cloud of the these words  into tfidf_wordCloud.pdf
		"""
		self._convert_into_word_cloud(freq, "tfidf_wordCloud.jpg")



def write_to_file(freq):
	write_file = WriteToFile()
	with open("tf_list.csv", "w") as file:
		wr = csv.writer(file, quoting=csv.QUOTE_ALL)
		for (key, value) in freq:
			wr.writerow([key, value])

def clear_text(text):
	filtering = Filtering()
	return filtering.get_feature_vector(filtering.process_text(text))


if __name__ == '__main__':
	print "starting program"
	files = ["deneme.txt", "deneme.txt"]
	get_documents =  ReadFromFile()
	word_freq = WordFreq()
	# redirect according to their file extension
	for file in files:
		filename, extension = tuple(file.split("."))
		if extension == "txt":
			text = get_documents.get_text_from_txt(filename+".txt")
		elif extension == "pdf":
			text = get_documents.get_text_from_txt("articles/deneme.pdf")
		else:
			text = get_documents.get_text_from_txt("articles/deneme.doc")

		word_freq.most_frequents(clear_text(text))	



	freq = sorted(word_freq.frequent.items(), key=operator.itemgetter(1), reverse=True)[:50]
	# last step 
	write_to_file(freq)
	word_freq.word_cloud(freq)



