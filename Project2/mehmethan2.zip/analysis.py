import math
import operator
import csv
from os import path, listdir
from os.path import isfile, join
from subprocess import Popen, PIPE

from PIL import Image
import numpy as np
from docx import opendocx, getdocumenttext
from wordcloud import WordCloud
import matplotlib.pyplot as plt
from cStringIO import StringIO
from pdfminer.pdfinterp import PDFResourceManager, PDFPageInterpreter
from pdfminer.converter import TextConverter
from pdfminer.layout import LAParams
from pdfminer.pdfpage import PDFPage

from filtering import Filtering

d = path.dirname(__file__)

class GetDocuments():
	"""docstring for GetDocuments"""
	def __init__(self):
		pass


class ReadFromFile():
	"""docstring for ReadFromFile"""
	def __init__(self):
		pass

	def get_text_from_txt(self, filename):
		return open(filename).read()

	def get_text_from_docx(self, filename):
		""" 
			use doc module
			python doc 
		"""
		document = opendocx(filename)
		paratextlist = getdocumenttext(document)
		newparatextlist = [paratext.encode("utf-8") for paratext in paratextlist]
		return ' '.join(newparatextlist)

	def get_text_from_doc(self, filename):
		cmd = ['antiword', file_path]
		p = Popen(cmd, stdout=PIPE)
		stdout, stderr = p.communicate()
		return stdout.decode('ascii', 'ignore')

	def convert_pdf_to_text(self, fname, pages={}):
		""" 
			Read from pdf and convert into text
		"""
		output = StringIO()
		manager = PDFResourceManager()
		converter = TextConverter(manager, output, codec='utf-8', laparams=LAParams())
		interpreter = PDFPageInterpreter(manager, converter)

		infile = open(fname, 'rb')
		for page in PDFPage.get_pages(infile, pages):
			interpreter.process_page(page)
		infile.close()
		converter.close()
		text = output.getvalue()
		output.close
		return text 


class WriteToFile():
	def write_to_csv(self, filenane):
		pass


class WordFreq():
	"""docstring for WordFreq"""
	def __init__(self):
		self.frequent = {}
		self.frequent_file = {}

	def _convert_into_word_cloud(self, freq, filename):
		key_array = [key for (key, value) in freq]
		wordcloud = WordCloud().generate(" ".join(key_array))
		wordcloud.to_file(path.join(filename))

	def most_frequents(self, text, filename):
		"""
			tf_list.csv
			Most frequent 50 words in the input set of documents, sorted descending
		by their term frequency (tf) coupled with their tf values (comma seperated file,
		example: document;7)
		"""
		for word in text:
			# total based store
			self.frequent[word] = self.frequent.get(word, 0) + 1
			# file based store
			self.frequent_file[filename][word] = self.frequent_file[filename].get(word, 0) + 1
		return self.frequent

	def word_cloud(self, freq):
		"""
			tf_wordCloud.pdf
			Word cloud of the these words
		"""
		self._convert_into_word_cloud(freq, "tf_wordCloud.pdf")


	def tf(self, word, filename, freq):
		return self.frequent_file[filename][word] /  float(freq[0][1])

	def n_containing(self, word, document_list):
		return sum(1 for filename in document_list if word in self.frequent_file[filename].keys())

	def idf(self, word, document_list):
		return abs(math.log(len(document_list) / float((1 + self.n_containing(word, document_list)))))

	def tfidf(self, word, filename, document_list, freq):
		return self.tf(word, filename, freq) * self.idf(word, document_list)


def write_to_file(freq, files):
	write_file = WriteToFile()
	with open("tf_list.csv", "w") as file:
		wr = csv.writer(file, quoting=csv.QUOTE_ALL)
		for (key, value) in freq:
			wr.writerow([key, value])

def clear_text(text):
	filtering = Filtering()
	return filtering.get_feature_vector(filtering.process_text(text))


if __name__ == '__main__':
	print "starting program...."
	doc_path = raw_input("please give documents path (example: /home/Desktop) : ")
	files = [f for f in listdir(doc_path) if isfile(join(doc_path, f)) and f.split(".")[1] in ["txt", "doc", "docx", "pdf"]]
	get_documents =  ReadFromFile()
	word_freq = WordFreq()
	# initialize file based store
	for file in files:
		word_freq.frequent_file[file] = {}
	# redirect according to their file extension
	for file in files:
		filename, extension = tuple(file.split("."))
		if extension == "txt":
			text = get_documents.get_text_from_txt("articles/"+file)
		elif extension == "pdf":
			text = get_documents.convert_pdf_to_text("articles/"+file)
		elif extension == "docx":
			text = get_documents.get_text_from_docx("articles/"+file)
		else:
			text = get_documents.get_text_from_txt("articles/deneme.doc")

		word_freq.most_frequents(clear_text(text), file)	

	freq = sorted(word_freq.frequent.items(), key=operator.itemgetter(1), reverse=True)[:50]
	# last step 
	write_to_file(freq, files)
	word_freq.word_cloud(freq)

	for i, file in enumerate(files):
		print("Top words in document {}".format(i + 1))
		scores = {word: word_freq.tfidf(word, file, files, freq) for word in word_freq.frequent_file[file].keys()}
		sorted_words = sorted(scores.items(), key=lambda x: x[1], reverse=True)
		for word, score in sorted_words[:10]:
			print("\tWord: {}, TF-IDF: {}".format(word, round(score, 5)))
